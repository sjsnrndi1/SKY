﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sound : MonoBehaviour {

    public AudioSource source; 
    public AudioClip click;

	void Start () {

	}

    void Update () {
        if (Input.GetMouseButtonDown(0))
            playSound();
    }

    public void playSound()
    {
        source.PlayOneShot(click, 1.0f);
    }
}
