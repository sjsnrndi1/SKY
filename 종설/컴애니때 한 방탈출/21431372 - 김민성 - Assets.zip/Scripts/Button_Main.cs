﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Button_Main : MonoBehaviour {

    public void OnGUI()
    { 
        SceneManager.LoadScene("Narrtion");
    }

    public void OnGUI1()
    {
        SceneManager.LoadScene("FirstCh");
    }

    public void OnGUI2()
    {
        SceneManager.LoadScene("SecondCh");
    }

    public void OnGUI3()
    {
        SceneManager.LoadScene("ThirdCh");
    }

    public void EXIT()
    {
        SceneManager.LoadScene("FinishCh");
    }
}
