﻿using UnityEngine;

public class Inventory : MonoBehaviour {
    
    public GameObject PaperquizButton;
    public GameObject PaperboxButton;
    public GameObject KeyButton;
    public GameObject KeyClickButton;
    public GameObject Cabinet;
    public GameObject Cabinet2;
    public GameObject DriverButton;
    public GameObject DriverClickButton;

    int[] open = new int[3];
    int[] key = new int[3];
    int[] driver = new int[3];
    
    int hide = 0;

    void Start()
    {
        for (int i = 0; i < 3; i++)
        {
            open[i] = 0;
            key[i] = 0;
            driver[i] = 0;
        }
    }

    public void PaperquizButtonOnclick()
    {
        PaperquizButton.gameObject.SetActive(true);
        if (open[0].Equals(0))
        {
            PaperquizButton.transform.position = new Vector3(104, 340);
            open[0] = 1;
        }
        else if(open[0].Equals(1) && open[1].Equals(0))
        {
            PaperquizButton.transform.position = new Vector3(104, 220);
            open[1] = 1;
        }
        else if (open[0].Equals(1) && open[1].Equals(1) && open[2].Equals(0))
        {
            PaperquizButton.transform.position = new Vector3(104, 100);
            open[2] = 1;
        }
    }

    public void PaperboxButtonOnclick()
    {
        PaperboxButton.gameObject.SetActive(true);
        if (open[0].Equals(0))
        {
            PaperboxButton.transform.position = new Vector3(104, 340);
            open[0] = 1;
        }
        else if (open[0].Equals(1) && open[1].Equals(0))
        {
            PaperboxButton.transform.position = new Vector3(104, 220);
            open[1] = 1;
        }
        else if (open[0].Equals(1) && open[1].Equals(1) && open[2].Equals(0))
        {
            PaperboxButton.transform.position = new Vector3(104, 100);
            open[2] = 1;
        }
    }

    public void KeyButtonOnclick()
    {
        KeyButton.gameObject.SetActive(true);
        if (open[0].Equals(0))
        {
            KeyButton.transform.position = new Vector3(104, 340);
            open[0] = 1;
            key[0] = 1;
        }
        else if (open[0].Equals(1) && open[1].Equals(0))
        {
            KeyButton.transform.position = new Vector3(104, 220);
            open[1] = 1;
            key[1] = 1;
        }
        else if (open[0].Equals(1) && open[1].Equals(1) && open[2].Equals(0))
        {
            KeyButton.transform.position = new Vector3(104, 100);
            open[2] = 1;
            key[2] = 1;
        }
    }

    public void KeyClickButtonOnclick()
    {
        KeyClickButton.gameObject.SetActive(true);
        KeyButton.gameObject.SetActive(false);
        if (key[0].Equals(1))
        {
            KeyClickButton.transform.position = new Vector3(104, 340);
        }
        else if (key[1].Equals(1))
        {
            KeyClickButton.transform.position = new Vector3(104, 220);
        }
        else if (key[2].Equals(1))
        {
            KeyClickButton.transform.position = new Vector3(104, 100);
        }
    }

    public void DriverButtonClick()
    {
        DriverButton.gameObject.SetActive(true);
        if (open[0].Equals(0))
        {
            DriverButton.transform.position = new Vector3(104, 340);
            open[0] = 1;
            driver[0] = 1;
        }
        else if (open[0].Equals(1) && open[1].Equals(0))
        {
            DriverButton.transform.position = new Vector3(104, 220);
            open[1] = 1;
            driver[1] = 1;
        }
        else if (open[0].Equals(1) && open[1].Equals(1) && open[2].Equals(0))
        {
            DriverButton.transform.position = new Vector3(104, 100);
            open[2] = 1;
            driver[2] = 1;
        }
    }

    public void DriverClickButtonOnclick()
    {
        DriverClickButton.gameObject.SetActive(true);
        DriverButton.gameObject.SetActive(false);
        if (driver[0].Equals(1))
        {
            DriverClickButton.transform.position = new Vector3(104, 340);
        }
        else if (driver[1].Equals(1))
        {
            DriverClickButton.transform.position = new Vector3(104, 220);
        }
        else if (driver[2].Equals(1))
        {
            DriverClickButton.transform.position = new Vector3(104, 100);
        }
    }
    
    public void IronButtonOnclick()
    {
        hide = 1;
    }

    public void CabinetButtonOnclick()
    {
        if (hide.Equals(1))
        {
            Cabinet.gameObject.SetActive(false);
            Cabinet2.gameObject.SetActive(true);
        }
    }

    public void Cabinet2ButtonOnclick()
    {
        if (hide.Equals(1))
        {
            Cabinet.gameObject.SetActive(true);
            Cabinet2.gameObject.SetActive(false);
        }
    }

    public void Reset()
    {
        for(int i = 0; i < 3; i++)
        {
            if (key[i].Equals(1))
            {
                hide = 0;
                open[i] = 0;
            } else if (driver[i].Equals(1))
            {
                open[i] = 0;
            }
        }   
    }
}