﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory2 : MonoBehaviour
{

    public GameObject OilButton;
    public GameObject OilGainButton;
    public GameObject FireButton;
    public GameObject FireGainButton;
    public GameObject Iron1;
    public GameObject Key;
    public GameObject Keyclick;

    int[] open = new int[3];
    int[] save = new int[3];
    int[] count = new int[3];
    int[] key = new int[3];
    int ct;

    void Start()
    {
        OilButton.gameObject.SetActive(false);
        OilGainButton.gameObject.SetActive(false);
        FireButton.gameObject.SetActive(false);
        FireGainButton.gameObject.SetActive(false);
        Iron1.gameObject.SetActive(false);
        Key.gameObject.SetActive(false);
        Keyclick.gameObject.SetActive(false);

        ct = 0;

        for (int i = 0; i < 3; i++)
        {
            open[i] = 0;
            save[i] = 0;
            count[i] = 0;
            key[i] = 0;
        }
    }

    public void KeyClick()
    {
        Key.gameObject.SetActive(true);
        if (open[0].Equals(0))
        {
            Key.transform.position = new Vector3(104, 340);
            open[0] = 1;
            key[0] = 1;
        }
        else if (open[0].Equals(1) && open[1].Equals(0))
        {
            Key.transform.position = new Vector3(104, 220);
            open[1] = 1;
            key[1] = 1;
        }
        else if (open[0].Equals(1) && open[1].Equals(1) && open[2].Equals(0))
        {
            Key.transform.position = new Vector3(104, 100);
            open[2] = 1;
            key[2] = 1;
        }
    }

    public void KeyGainClick()
    {
        Key.gameObject.SetActive(false);
        Keyclick.gameObject.SetActive(true);
        if (key[0].Equals(1))
        {
            Keyclick.transform.position = new Vector3(104, 340);
        }
        else if (key[1].Equals(1))
        {
            Keyclick.transform.position = new Vector3(104, 220);
        }
        else if (key[2].Equals(1))
        {
            Keyclick.transform.position = new Vector3(104, 100);
        }
    }

    public void OilClick()
    {
        OilButton.gameObject.SetActive(true);
        if (open[0].Equals(0))
        {
            OilButton.transform.position = new Vector3(104, 340);
            open[0] = 1;
            count[0] = 1;
        }
        else if (open[0].Equals(1) && open[1].Equals(0))
        {
            OilButton.transform.position = new Vector3(104, 220);
            open[1] = 1;
            count[1] = 1;
        }
        else if (open[0].Equals(1) && open[1].Equals(1) && open[2].Equals(0))
        {
            OilButton.transform.position = new Vector3(104, 100);
            open[2] = 1;
            count[2] = 1;
        }
    }

    public void OilGainClick()
    {
        OilButton.gameObject.SetActive(false);
        OilGainButton.gameObject.SetActive(true);
        if (count[0].Equals(1))
        {
            OilGainButton.transform.position = new Vector3(104, 340);
        }
        else if (count[1].Equals(1))
        {
            OilGainButton.transform.position = new Vector3(104, 220);
        }
        else if (count[2].Equals(1))
        {
            OilGainButton.transform.position = new Vector3(104, 100);
        }
    }

    public void FireClick()
    {
        FireButton.gameObject.SetActive(true);
        if (open[0].Equals(0))
        {
            FireButton.transform.position = new Vector3(104, 340);
            open[0] = 1;
            save[0] = 1;
        }
        else if (open[0].Equals(1) && open[1].Equals(0))
        {
            FireButton.transform.position = new Vector3(104, 220);
            open[1] = 1;
            save[1] = 1;
        }
        else if (open[0].Equals(1) && open[1].Equals(1) && open[2].Equals(0))
        {
            FireButton.transform.position = new Vector3(104, 100);
            open[2] = 1;
            save[2] = 1;
        }
    }

    public void FireGainClick()
    {
        FireButton.gameObject.SetActive(false);
        FireGainButton.gameObject.SetActive(true);
        if (save[0].Equals(1))
        {
            FireGainButton.transform.position = new Vector3(104, 340);
        }
        else if (save[1].Equals(1))
        {
            FireGainButton.transform.position = new Vector3(104, 220);
        }
        else if (save[2].Equals(1))
        {
            FireGainButton.transform.position = new Vector3(104, 100);
        }
    }

    public void ResetFire()
    {
        for(int i = 0; i<3; i++)
        {
            if (save[i].Equals(1))
            {
                open[i] = 0;
                save[i] = 0;
            }
        }
    }

    public void ResetOil()
    {
        for (int i = 0; i < 3; i++)
        {
            if (count[i].Equals(1))
            {
                open[i] = 0;
                count[i] = 0;
                ct = 1;
            }
        }
    }

    public void Exp()
    {
        if(ct.Equals(1)) {
            Iron1.gameObject.SetActive(true);
        } else
        {
            Iron1.gameObject.SetActive(false);
        }
    }
}
